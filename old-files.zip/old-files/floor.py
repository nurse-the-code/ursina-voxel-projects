## WARNING: This is a WIP

import ursina as u
from ursina import collider

class Floor:
    def __init__(self):
        '''
        verts = ((-1024, 0, -1024), (1024, 0, -1024), (1024, 0, 1024), (-1024, 0, 1024))
        tris = (1, 2, 0, 2, 3, 0)
        floor_mesh = u.Entity(model = u.Mesh(vertices=verts, triangles=tris))
        '''
        floor = u.Entity(
            parent = u.scene,
            model = 'quad',
            visable = False,
            color = u.color.white,
            texture = 'noise',
            position = (-0.5, -1, -0.5),
            rotation_x = -90,
            scale = (64, 64, 64),
            collision = True,
            collider = 'quad'
        )